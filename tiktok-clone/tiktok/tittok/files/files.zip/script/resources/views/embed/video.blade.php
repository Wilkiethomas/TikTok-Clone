<div class="video-section">
    <video id='singlevideo' controls>
        <source src='{{ asset($video->url) }}' type='video/mp4'>
    </video>
    <div class="video-action">
        <a href="javascript:void(0)" class="play"><i class="fas fa-play"></i></a>
    </div>
</div>
